def wp_post_content():
    print('Yeeah')