import os

db_host = os.environ['kdb_host']
db_dbname = os.environ['kdb_name']
db_user = os.environ['kdb_user']
db_pwd = os.environ['kdb_pwd']
